let map;
let markers = [];
let polygon;
const labelColors = {
  1: 'red',     // You can assign specific colors for each label
  2: 'blue',
  3: 'green',
  4: 'orange',
  0: 'yellow'
};
function initMap() {
  map = new google.maps.Map(document.getElementById('map'), {
    center: { lat: 26.9124, lng: 75.7873 },
    zoom: 12
  });

  map.addListener('click', function (event) {
    addMarker(event.latLng);
  });

  fetch('markers.json')
  .then(response => response.json())
  .then(data => {
      data.forEach(markerData => {
          var lat = markerData[0];
          var lng = markerData[1];
          var label = markerData[2];

          addMarkerWithLabel(lat, lng, label);
      });
  })
  .catch(error => console.error('Error fetching JSON:', error));

function addMarker(location) {
  const marker = new google.maps.Marker({
    position: location,
    map: map,
    icon: getMarkerIcon(label)
  });
  markers.push(marker);
  console.log(markers);
}
}
function addMarkerWithLabel(lat, lng, label) {
  var marker = new google.maps.Marker({
      position: {lat: lat, lng: lng},
      map: map,
      label: label.toString(),
      icon: getMarkerIcon(label)
  });
}
function getMarkerIcon(label) {
  return {
    path: google.maps.SymbolPath.CIRCLE,
    fillColor: labelColors[label],
    fillOpacity: 1,
    strokeWeight: 0,
    scale: 8
  };
}

// Read data from JSON file and add markers


function lockArea() {
  if (markers.length < 3) {
      alert("You need at least 3 markers to create an area.");
      return;
  }

  if (polygon) {
      polygon.setMap(null);
  }

  // Create a polyline connecting the markers
  const polyLine = new google.maps.Polyline({
      path: markers.map(marker => marker.getPosition()),
      strokeColor: '#0000FF', // Color of the polyline
      strokeOpacity: 0.8,
      strokeWeight: 2,
      map: map
  });

  // Create a polygon filled with a color
  polygon = new google.maps.Polygon({
      paths: polyLine.getPath(), // Use getPath() directly
      strokeColor: '#FF0000',
      strokeOpacity: 0.8,
      strokeWeight: 2,
      fillColor: '#FF0000',
      fillOpacity: 0.35,
      editable: true,
      draggable: true,
      map: map
  });

  // Disable dragging while locking an area
  map.setOptions({ draggable: false });

  // Enable dragging after a short delay
  setTimeout(() => {
      map.setOptions({ draggable: true });
  }, 500);
}



function assignPoliceman() {
  const selectedPoliceman = document.getElementById('policeDropdown').value;

  if (!polygon) {
    alert("Lock an area before assigning a policeman.");
    return;
  }

  // You can handle the assignment logic here, for example, store the assigned policeman and the area details.

  alert(`Assigned ${selectedPoliceman} to the locked area.`);
}