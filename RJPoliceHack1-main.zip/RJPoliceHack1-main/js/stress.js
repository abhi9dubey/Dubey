window.addEventListener('load', function() {
 
const stressLevelElement = document.getElementById('stressLevel');
const stressLevel = Math.random() * 100; // You can replace this with your logic to get the actual stress level

// Limit stress level to be between 0 and 100
const clampedStressLevel = parseInt(Math.min(Math.max(stressLevel, 0), 100));
// Remove existing classes
stressLevelElement.className = 'stress-level';

// Apply color-coded class based on stress level
if (clampedStressLevel < 25) {
    stressLevelElement.classList.add('low');
} else if (clampedStressLevel < 50) {
    stressLevelElement.classList.add('medium');
} else if (clampedStressLevel < 75) {
    stressLevelElement.classList.add('high');
} else {
    stressLevelElement.classList.add('extreme');
}

stressLevelElement.style.width = clampedStressLevel + '%';




}, false);


function initMap() {
    // Initialize the map
    var map = new google.maps.Map(document.getElementById('map_container'), {
        center: {lat: 26.867420912127216, lng: 75.81905826931062},
        zoom: 16
    });
    var customMarkerIcon = {
        url: '../img/logo.png', // Replace with the path to your custom PNG
        scaledSize: new google.maps.Size(40, 40), // Adjust the size of the marker icon
    };
    
    // Add custom markers with the custom icon
    var marker = new google.maps.Marker({
        position: {lat: 26.867420912127216, lng: 75.81905826931062},
        map: map,
        title: 'Marker Title',
        icon: customMarkerIcon
    });
    
    // Add click event listener to the marker
    marker.addListener('click', function() {
        // Handle marker click event
        alert('Marker clicked!');
    });
}