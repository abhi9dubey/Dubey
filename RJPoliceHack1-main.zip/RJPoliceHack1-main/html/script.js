// script.js
$(document).ready(function () {
    // Load the Fitness API client library
    gapi.load('client', initClient);

    function initClient() {
        // Initialize the Fitness API client with your API key
        // Replace 'YOUR_API_KEY' with your actual API key
        gapi.client.init({
            apiKey: 'AIzaSyDWJS60xju9fZI0E7R0D7d4tKqbxGe4G8E',
            discoveryDocs: ["https://www.googleapis.com/discovery/v1/apis/fitness/v1/rest"],
        }).then(function () {
            // Ensure the Fitness API is properly loaded
            return gapi.client.load('fitness', 'v1');
        }).then(function () {
            // Make API requests to get data
            gapi.client.fitness.users.get({
                userId: 'me'
            }).then(function (response) {
                var userId = response.result.id;
                // Now that we have the userId, get the data for each metric
                getFitnessData(userId, 'com.google.step_count.delta', '#steps');
                getFitnessData(userId, 'com.google.oxygen_saturation', '#spo2');
                getFitnessData(userId, 'com.google.heart_rate.bpm', '#bpm');
                getFitnessData(userId, 'com.google.sleep.segment', '#sleep');
            }, function (reason) {
                console.error('Error getting user ID: ' + reason.result.error.message);
            });
        }, function (reason) {
            console.error('Error initializing Fitness API: ' + reason);
        });
    }


    function getFitnessData(userId, dataType, targetElement) {
        // Make a GET request to the Fitness API to get the data source ID for the specified data type
        gapi.client.fitness.users.dataSources.list({
            userId: 'me',
            dataTypeName: dataType
        }).then(function (response) {
            if (response.result.dataSource) {
                var dataSourceId = response.result.dataSource[0].dataStreamId;
                // Now that we have the dataSourceId, make a request to get the data
                makeDataRequest(userId, dataSourceId, targetElement, dataType);
            } else {
                console.error('No data source found for ' + dataType);
            }
        }, function (reason) {
            console.error('Error getting data sources: ' + reason.result.error.message);
        });
    }

    function makeDataRequest(userId, dataSourceId, targetElement, dataType) {
        // Make a GET request to the Fitness API to get data
        gapi.client.fitness.users.dataSources.get({
            userId: userId,
            dataSourceId: dataSourceId
        }).then(function (response) {
            if (response.result.point && response.result.point.length > 0) {
                // Extract data from the response
                var dataPoint = response.result.point[0].value[0].fpVal;
                // Update the HTML element
                $(targetElement).text(dataType + ': ' + dataPoint);
            } else {
                console.error('No data found for ' + dataType);
            }
        }, function (reason) {
            console.error('Error getting data: ' + reason.result.error.message);
        });
    }
});
